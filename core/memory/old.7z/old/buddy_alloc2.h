#pragma once
#ifndef BUDDY_ALLOC2_H
#define BUDDY_ALLOC2_H

#include "core/data/pointers.h"
#include "core/data/bytes.h"


namespace Memory {
    using Data::Bytes;
    using Data::Byte;
    using Data::Out;

    struct BuddyAlloc2 {
        static const size_t MAX_BINS = 16;
        static const size_t MIN_SIZE = 64;

        struct RegionInfo {
            static const size_t MAPLEN = 32 / sizeof(size_t);
            size_t memmap[MAPLEN];
            BuddyAlloc2* owner;

            RegionInfo(BuddyAlloc2* a);
        };
        struct ChunkInfo : RegionInfo {
            ChunkInfo* next;
        };
        struct Block {
            Block* prev;
            Block* next;
        };

        Block* bins[16];
        ChunkInfo* chunks;

        ~BuddyAlloc2();
        void* operator new(size_t size);
    };

    size_t getbuddy2level(size_t size);
    size_t getbuddy2size(size_t level);

    Bytes alloc(Out<BuddyAlloc2> a, size_t level);
    void dealloc2(Bytes bytes);

} // namespace Memory


#endif // BUDDY_ALLOC2_H