#pragma once
#ifndef MEMORY_STACK_H
#define MEMORY_STACK_H

#include "memory/buffer.h"


namespace Memory {
   template <class T>
   struct Stack {
      Buffer buffer;

   public:
      void push(T const& elem);
      T&   top() const;
      void pop();
   };

} // namespace Memory


#include "hpp/stack.hpp"

#endif // MEMORY_STACK_H