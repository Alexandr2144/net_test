#pragma once
#ifndef MEMORY_ARRAY_H
#define MEMORY_ARRAY_H

#include "core/data/array.h"
#include "memory/region.h"


namespace Memory {
   template <class T>
   class Range {
   public:
      Range() {}

      Range(const Range& arr) = delete;
      Range(Range&& arr) = delete;

      Range& operator=(const Range& arr) = delete;
      Range& operator=(Range&& arr) = delete;

      T const* operator[](size_t idx) const;
      T* operator[](size_t idx);

      Data::Array<T> asArray() const;
      Range expand() const;

   private:
      Region m_region;
   };


   template <class T>
   class Line {
   public:
      Line() {}

      Line(const Line& arr) = delete;
      Line(Line&& arr) = delete;

      Line& operator=(const Line& arr) = delete;
      Line& operator=(Line&& arr) = delete;

      T const& operator[](size_t idx) const;
      T& operator[](size_t idx);

      Data::Array<T> asArray(size_t n) const;

   private:
      mutable Region m_region;
   };


   template <class T>
   struct RaStack {
   public:
      RaStack();

      RaStack(const RaStack& arr) = delete;
      RaStack(RaStack&& arr) = delete;

      RaStack& operator=(const RaStack& arr) = delete;
      RaStack& operator=(RaStack&& arr) = delete;

      T const& operator[](size_t idx) const;
      T& operator[](size_t idx);

      Data::Array<T> asArray() const;
      size_t append(T const& val);
      size_t emplace(T&& val);
      T* alloc();

      size_t last() const { return m_top - 1; }

   private:
      mutable Region m_region;
      size_t m_top;
   };

} // namespace Memory


#include "hpp/array.hpp"

#endif // MEMORY_ARRAY_H