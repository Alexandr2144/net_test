#pragma once
#ifndef MEMORY_REGION_H
#define MEMORY_REGION_H

#include "core/data/bytes.h"


namespace Memory {
   using Data::Bytes;
   using Data::Byte;


   class Region {
   public:
      Region();
      ~Region();

      Bytes reserve(size_t offset);
      Bytes read(size_t offset = 0) const;
      size_t last() const;

   private:
      size_t m_last;
      Bytes m_bytes;
   };

} // namespace Memory


#endif // MEMORY_REGION_H