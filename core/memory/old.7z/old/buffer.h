#pragma once
#ifndef MEMORY_BUFFER_H
#define MEMORY_BUFFER_H

#include "core/data/pointers.h"
#include "core/data/bytes.h"


namespace Memory {
   using Data::Bytes;
   using Data::Byte;


   class Buffer {
      struct Chunk {
         Chunk* prev;
         Chunk* next;
         Byte* last;
         Byte* end;
      };
   public:
      Buffer(size_t startsize = 0);
      ~Buffer();

      void back(size_t count);
      void write(Bytes bytes);
      void fixwrite(Bytes bytes);
      Bytes reserve(size_t count);

      Bytes flush(Bytes dest) const;
      Byte* top() const;

   private:
      size_t m_lvl;
      Chunk* m_chunk;
      Chunk* m_first;

      void  _back(size_t count);
      bool  _owerflow(size_t count);
      Bytes _flush(Chunk* chunk, Bytes dest) const;
      void  _extend(size_t count, bool init);
      void  _clear();
   };

} // namespace Memory


#endif // MEMORY_BUFFER_H