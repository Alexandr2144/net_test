#pragma once
#ifndef MEMORY_OPEN_INDEX_H
#define MEMORY_OPEN_INDEX_H

#include "core/data/open_index.h"
#include "core/data/pointers.h"
#include "core/data/string.h"
#include "core/data/array.h"


#define M_OPEN_INDEX_STORAGE(VAL_TYPE, HASH_MEMBER, ARRAY) \
    Memory::OpenIndex::StorageInfo{ (ARRAY).begin, Data::count(ARRAY), sizeof(VAL_TYPE), offsetof(VAL_TYPE, HASH_MEMBER) }


namespace Memory {
    struct OpenIndex {
        Data::OpenIndex index;

    public:
        struct StorageInfo {
            void* begin;
            size_t count;
            size_t elemSize;
            size_t hashOffset;
        };

        OpenIndex();

        bool extend(StorageInfo storage);
        bool insert(size_t hashval, StorageInfo storage);

        bool isEmpty() const;
        bool isUsed(size_t entry) const;
        size_t id(size_t entry) const;

        Data::Range getrange(size_t hashval) const;

    };

    using OpenIndex_CRef = OpenIndex const&;


    template <class KeyTy, class GetterTy>
    size_t lookup(OpenIndex_CRef index, KeyTy const& key, GetterTy const& getter)
    {
        if (index.isEmpty() == 0) return SIZE_MAX;
        auto recArray = records.asArray();

        Data::Range range = index.getrange(hash(key));
        for (size_t place = range.begin; place != range.end; ++place) {
            if (!index.isUsed(place)) continue;

            size_t id = index.id(place);
            if (getter(id) == key) return id;
        }

        return SIZE_MAX;
    }
}


#endif // MEMORY_OPEN_INDEX_H