#include "memory/array.h"

#include "core/tools/assert.h"


namespace Memory {
   using Data::iterate;


   // -------------------------------------------------------------------------
   template <class T>
   T const* Range<T>::operator[](size_t idx) const
   {
      Tools::assert_msg(asArray().begin + idx < asArray().end, "Out of range");
      return asArray().begin + idx;
   }

   // -------------------------------------------------------------------------
   template <class T>
   T* Range<T>::operator[](size_t idx)
   {
      Tools::assert_msg(asArray().begin + idx < asArray().end, "Out of range");
      return asArray().begin + idx;
   }

   // -------------------------------------------------------------------------
   template <class T>
   Data::Array<T> Range<T>::asArray() const
   {
      Data::Bytes bytes = m_region.read();
      return Data::Array<T>{ (T*)bytes.begin, (T*)bytes.end };
   }

   // -------------------------------------------------------------------------
   template <class T>
   Range<T> Range<T>::expand() const
   {
      return Range<T>{ m_region.expand() };
   }

   // -------------------------------------------------------------------------
   template <class T>
   T const& Line<T>::operator[](size_t idx) const
   {
      return asArray(idx).begin[idx];
   }

   // -------------------------------------------------------------------------
   template <class T>
   T& Line<T>::operator[](size_t idx)
   {
      return asArray(idx).begin[idx];
   }

   // -------------------------------------------------------------------------
   template <class T>
   Data::Array<T> Line<T>::asArray(size_t n) const
   {
      m_region.reserve(sizeof(T) * (n + 1));

      Data::Bytes bytes = m_region.read();
      return Data::Array<T>{ (T*)bytes.begin, (T*)bytes.begin + n };
   }

   // -------------------------------------------------------------------------
   template <class T>
   RaStack<T>::RaStack()
      : m_top(0)
   {
   }

   // -------------------------------------------------------------------------
   template <class T>
   T const& RaStack<T>::operator[](size_t idx) const
   {
      M_ASSERT(idx <= m_top);
      return asArray().begin[idx];
   }

   // -------------------------------------------------------------------------
   template <class T>
   T& RaStack<T>::operator[](size_t idx)
   {
      M_ASSERT(idx <= m_top);
      return asArray().begin[idx];
   }

   // -------------------------------------------------------------------------
   template <class T>
   Data::Array<T> RaStack<T>::asArray() const
   {
      Data::Bytes bytes = m_region.read();
      return Data::Array<T>{ (T*)bytes.begin, (T*)bytes.begin + m_top };
   }

   // -------------------------------------------------------------------------
   template <class T>
   size_t RaStack<T>::append(T const& val)
   {
      new(alloc()) T(val);
      return m_top - 1;
   }

   // -------------------------------------------------------------------------
   template <class T>
   size_t RaStack<T>::emplace(T&& val)
   {
      new(alloc()) T(std::forward<T>(val));
      return m_top - 1;
   }

   // -------------------------------------------------------------------------
   template <class T>
   T* RaStack<T>::alloc()
   {
       m_region.reserve((++m_top) * sizeof(T));

       Data::Bytes bytes = m_region.read();
       return ((T*)bytes.begin) + m_top - 1;
   }

} // namespace Memory