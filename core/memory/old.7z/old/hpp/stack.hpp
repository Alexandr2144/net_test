#include "memory/stack.h"


namespace Memory {
   // -------------------------------------------------------------------------
   template <class T>
   void Stack<T>::push(T const& elem)
   {
      buffer.write(Data::toBytes(&elem));
   }

   // -------------------------------------------------------------------------
   template <class T>
   T& Stack<T>::top() const
   {
      return *(T*)(buffer.top() - sizeof(T));
   }

   // -------------------------------------------------------------------------
   template <class T>
   void Stack<T>::pop()
   {
      buffer.back(sizeof(T));
   }

} // namespace Memory