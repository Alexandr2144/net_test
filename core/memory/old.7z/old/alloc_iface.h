#pragma once
#ifndef MEMORY_ALLOC_IFACE
#define MEMORY_ALLOC_IFACE


namespace Memory {
    struct IStaticAlloc {
        virtual void* alloc(size_t size) = 0;
    };

    struct IStackAlloc {
        virtual void* alloc(size_t size) = 0;
        virtual void dealloc(size_t size) = 0;
        virtual bool empty() const = 0;
    };


    // -------------------------------------------------------------------------
    template <class T, class... ArgsTy>
    static T* emplace(Memory::IStackAlloc& stack, ArgsTy&&... args)
    {
       void* ptr = stack.alloc(sizeof(T));
       new(ptr) T(std::forward<ArgsTy>(args)...);
       return (T*)ptr;
    }

} // namespace Memory


#endif // MEMORY_ALLOC_IFACE