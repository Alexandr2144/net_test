#pragma once
#ifndef MEMORY_BUDDY_ALLOCATOR_H
#define MEMORY_BUDDY_ALLOCATOR_H

#include "core/data/bytes.h"
#include "core/data/pointers.h"
#include "core/tools/logger.h"


namespace Memory {
	using Data::Bytes;
	using Data::Byte;
    using Data::Out;

	struct BuddyAllocator {
        static const size_t MAX_BINS = 16;
        static const size_t MIN_SIZE = 64;

		struct Chunk {
			Chunk* prev;
			Chunk* next;
            void* mem;
            void* end;

			BuddyAllocator* owner;
		};
		struct Block {
            static const size_t HEADER_SIZE = 8;
            static const size_t USED_BIT = 0x10;

			uintptr_t handle;
			Block* prev;
			Block* next;

            bool isfree() const;
            Chunk* owner() const;
            size_t level() const;
            void setattr(size_t lvl, size_t bits);

            static Bytes freespace(Block* block, size_t size);
            static Block* fromspace(Bytes bytes);
		};

        Block* bins[MAX_BINS];
        Chunk* chunks;

		 BuddyAllocator();
		~BuddyAllocator();
	};

    size_t getbuddylevel(size_t size);
    size_t getbuddysize(size_t level);

    Bytes alloc(Out<BuddyAllocator> a, size_t level);
    void  dealloc(Bytes bytes);

} // namespace Memory


#endif // MEMORY_BUDDY_ALLOCATOR_H