#pragma once
#ifndef MEMORY_STATIC_HEAP_H
#define MEMORY_STATIC_HEAP_H

#include "core/data/linked_list.h"
#include "core/data/avl_tree.h"


namespace Memory {
	using Data::SingleListNode;

	struct StaticHeap {
		struct Chunk {
			SingleListNode node;
		};

		Data::SingleListHead chunks;
		//Data::AvlTree<size_t> unused;
	};

} // namespace Memory


#endif // MEMORY_STATIC_HEAP_H