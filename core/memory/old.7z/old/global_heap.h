#pragma once
#ifndef MEMORY_GLOBAL_HEAP_H
#define MEMORY_GLOBAL_HEAP_H

#include "core/data/bytes.h"

#define M_BUDDY_STRATEGY_BYMASK 0
#define M_BUDDY_STRATEGY_BYNODE 1
#define M_BUDDY_STRATEGY_MALLOC 2
#define M_BUDDY_STRATEGY_DLMALLOC 3


namespace Memory {
   using Data::Bytes;

   Bytes buddy_alloc(size_t level, size_t minsize);
   Bytes buddy_realloc(Bytes bytes, size_t minsize);
   void  buddy_dealloc(Bytes bytes);

} // namespace Memory


#endif // MEMORY_GLOBAL_HEAP_H