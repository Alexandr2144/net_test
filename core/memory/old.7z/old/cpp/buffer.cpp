#include "memory/buffer.h"
#include "memory/global_heap.h"


namespace Memory {
   // -------------------------------------------------------------------------
   Buffer::Buffer(size_t startsize)
      : m_lvl(0)
      , m_chunk(nullptr)
      , m_first(nullptr)
   {
      _extend(startsize, true);
   }

   // -------------------------------------------------------------------------
   Buffer::~Buffer()
   {
      _clear();
   }

   // -------------------------------------------------------------------------
   void Buffer::back(size_t count)
   {
       Byte* begin = (Byte*)m_chunk;
       size_t tail = m_chunk->last - begin;
       while (count > tail) {
           count -= tail;
           begin = (Byte*)m_chunk;

           m_chunk->last = begin;
           m_chunk = m_chunk->prev;
           tail = m_chunk->last - begin;
       }
       m_chunk->last -= count;
   }

   // -------------------------------------------------------------------------
   Bytes Buffer::reserve(size_t count)
   {
       Byte* begin = top();
       if (_owerflow(count)) _extend(count, false);
       M_ASSERT(!_owerflow(count));

       Byte* mem = m_chunk->last;
       m_chunk->last += count;

       return Bytes{ begin, top() };
   }

   // -------------------------------------------------------------------------
   void Buffer::write(Bytes src)
   {
      size_t count = Data::count(src);
      Bytes dest = reserve(count);

      bool ok = Data::bytecopy(src, dest);
      M_ASSERT(ok);
   }

   // -------------------------------------------------------------------------
   void Buffer::fixwrite(Bytes bytes)
   {
      size_t count = bytes.end - bytes.begin;
      M_ASSERT(!_owerflow(count));

      Byte* mem = m_chunk->last;
      m_chunk->last += count;

      bool ok = Data::bytecopy(bytes, Bytes{ mem, m_chunk->end });
      M_ASSERT(ok);
   }

   // -------------------------------------------------------------------------
   Byte* Buffer::top() const
   {
      return m_chunk->last;
   }

   // -------------------------------------------------------------------------
   Bytes Buffer::flush(Bytes dest) const
   {
      for (Chunk* chunk = m_first; chunk; chunk = chunk->next) {
         dest = _flush(chunk, dest);
      }
      return dest;
   }

   // -------------------------------------------------------------------------
   Bytes Buffer::_flush(Chunk* chunk, Bytes dest) const
   {
      Bytes src{ (Byte*)chunk + sizeof(Chunk), chunk->end };

      Bytes forWriting;
      Bytes tail = Data::split(dest, &forWriting, Data::count(src));

      Data::bytecopy(src, forWriting);
      return tail;
   }

   // -------------------------------------------------------------------------
   bool Buffer::_owerflow(size_t count)
   {
       if (m_chunk == nullptr) {
           return true;
       }
       return (m_chunk->last + count > m_chunk->end);
   }

   // -------------------------------------------------------------------------
   void Buffer::_back(size_t count)
   {
      m_chunk->last -= count;
   }

   // -------------------------------------------------------------------------
   void Buffer::_extend(size_t count, bool init)
   {
      size_t minSize = count + sizeof(Chunk);
      Bytes memory = buddy_alloc(m_lvl, minSize);

      Chunk* chunk = (Chunk*)memory.begin;
      chunk->last = memory.begin + sizeof(Chunk);
      chunk->end = memory.end;

      chunk->next = nullptr;
      chunk->prev = m_chunk;

      m_lvl += 1;
      m_chunk = chunk;
      if (init) {
         m_first = chunk;
      } else {
         M_ASSERT(m_chunk != nullptr);
         m_chunk->next = chunk;
      }
   }

   // -------------------------------------------------------------------------
   void Buffer::_clear()
   {
      Chunk* chunk = m_chunk;
      while (chunk) {
         Bytes bytes{ (Byte*)chunk, chunk->end };
         chunk = chunk->prev;

         buddy_dealloc(bytes);
      }
   }

} // namespace Memory