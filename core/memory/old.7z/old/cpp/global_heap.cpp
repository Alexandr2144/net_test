#include "memory/global_heap.h"
#include "core/math/basic.h"
#include "core/data/bytes.h"


#define M_BUDDY_STRATEGY M_BUDDY_STRATEGY_MALLOC

#if (M_BUDDY_STRATEGY == M_BUDDY_STRATEGY_MALLOC)
#  include <malloc.h>
#  define M_BUDDY_STD_WRAPPER
#  define M_BUDDY_ALLOC_IMPL   malloc
#  define M_BUDDY_REALLOC_IMPL realloc
#  define M_BUDDY_DEALLOC_IMPL free
#elif  (M_BUDDY_STRATEGY == M_BUDDY_STRATEGY_DLMALLOC)
#  include "memory/dlmalloc.h"
#  define M_BUDDY_STD_WRAPPER
#  define M_BUDDY_ALLOC_IMPL   dlmalloc
#  define M_BUDDY_REALLOC_IMPL dlrealloc
#  define M_BUDDY_DEALLOC_IMPL dlfree
#endif // M_BUDDY_STRATEGY

#ifdef M_BUDDY_STD_WRAPPER
#define M_BUDDY_WRAPPER(NAME) NAME##_stdwrap
#endif // M_BUDDY_WRAPPED


namespace Memory {
   using Data::Bytes;
   using Data::Byte;


   // -------------------------------------------------------------------------
   static Bytes buddy_alloc_stdwrap(size_t level, size_t minsize)
   {
      size_t lvlsize = (size_t(1) << (level + 6));
      size_t size = Math::max(minsize, lvlsize);
      Byte* memory = (Byte*)M_BUDDY_ALLOC_IMPL(size);

      return Bytes{ memory, memory + size };
   }

   // -------------------------------------------------------------------------
   static Bytes buddy_realloc_stdwrap(Bytes bytes, size_t minsize)
   {
      size_t lvlsize = 2 * (bytes.end - bytes.begin);
      size_t size = Math::max(minsize, lvlsize);
      Byte* memory = (Byte*)M_BUDDY_REALLOC_IMPL(bytes.begin, size);

      return Bytes{ memory, memory + size };
   }

   // -------------------------------------------------------------------------
   static void buddy_dealloc_stdwrap(Bytes bytes)
   {
      M_BUDDY_DEALLOC_IMPL(bytes.begin);
   }

   // -------------------------------------------------------------------------
   Bytes buddy_alloc(size_t level, size_t minsize)
   {
      return M_BUDDY_WRAPPER(buddy_alloc)(level, minsize);
   }

   // -------------------------------------------------------------------------
   Bytes buddy_realloc(Bytes bytes, size_t minsize)
   {
      return M_BUDDY_WRAPPER(buddy_realloc)(bytes, minsize);
   }

   // -------------------------------------------------------------------------
   void buddy_dealloc(Bytes bytes)
   {
      M_BUDDY_WRAPPER(buddy_dealloc)(bytes);
   }

} // namespace Memory