#include "memory/open_index.h"

#include "core/tools/memory.h"
#include "core/math/basic.h"


namespace Memory {
    // -------------------------------------------------------------------------
    OpenIndex::OpenIndex()
    {
    }

    // -------------------------------------------------------------------------
    size_t OpenIndex::id(size_t entry) const
    {
        using IndexRecord = Data::OpenIndex::Record;

        IndexRecord& record = Data::get(index.table, entry);
        return record.id;
    }

    // -------------------------------------------------------------------------
    bool OpenIndex::isEmpty() const
    {
        return (index.count == 0);
    }

    // -------------------------------------------------------------------------
    bool OpenIndex::isUsed(size_t entry) const
    {
        return Data::used(index, entry);
    }

    // -------------------------------------------------------------------------
    Data::Range OpenIndex::getrange(size_t hashval) const
    {
        return Data::getrange(index, hashval % index.count);
    }

    // -------------------------------------------------------------------------
    bool OpenIndex::insert(size_t hashval, StorageInfo storage)
    {
        if (index.count == 0) extend(storage);

        size_t id = Data::insert(index, hashval % index.count, storage.count);
        while (id != SIZE_MAX) {
            if (!extend(storage)) {
                Tools::assert_fail(M_CL, "Hash table overflowed");
                return false;
            }
            id = Data::insert(index, hashval % index.count, id);
        }

        return true;
    }

    // -------------------------------------------------------------------------
    bool OpenIndex::extend(StorageInfo vals)
    {
        using IndexRecord = Data::OpenIndex::Record;
        using Data::count;

        Bytes hashes = Data::toBytes(vals.begin, vals.elemSize * vals.count);

        Data::OpenIndex newIndex;
        size_t prevLength = Math::max(count(index.table), (size_t)4);
        for (size_t length = prevLength << 1; true; length <<= 1) {

            auto storage = Tools::allocArray<IndexRecord>(length);
            if (Data::isEmpty(storage)) return false;

            newIndex = Data::OpenIndex(storage);
            if (newIndex.count == 0) return false;

            bool rehashed = rehash(index, newIndex, hashes, vals.hashOffset, vals.elemSize);
            if (rehashed) break;

            Tools::deallocArray(storage);
        }

        Tools::deallocArray(index.table);
        index = newIndex;
        return true;
    }

} // namespace Memory