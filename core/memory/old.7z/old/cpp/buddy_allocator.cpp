#include "memory/buddy_allocator.h"
#include "core/math/basic.h"
#include "native/memory.h"

#include <malloc.h>
#include <memory.h>


namespace Memory {
    using Chunk = BuddyAllocator::Chunk;
    using Block = BuddyAllocator::Block;


    // ------------------------------------------------------------------------
    size_t getbuddylevel(size_t size)
    {
        static const size_t base = Math::log2(BuddyAllocator::MIN_SIZE);
        size_t power = Math::log2(int(2 * size - 1));
        return power - base;
    }

    // ------------------------------------------------------------------------
    size_t getbuddysize(size_t level)
    {
        static const size_t base = Math::log2(BuddyAllocator::MIN_SIZE);
        return size_t(1) << (level + base);
    }

    // ------------------------------------------------------------------------
    static void allocNewChunk(Out<BuddyAllocator> a)
    {
        static const size_t CHUNKSIZE = BuddyAllocator::MIN_SIZE * (1 << BuddyAllocator::MAX_BINS);
        static const size_t CNKINF_SIZE = (sizeof(Chunk) + 31) & ~31;

        uintptr_t rawptr = (uintptr_t)malloc(2 * CNKINF_SIZE);
        Chunk* chunk = (Chunk*)(rawptr + 31 & ~31);
        M_ASSERT(((uintptr_t)chunk & 0x1F) == 0);

        chunk->mem = Native::mcommit(nullptr, CHUNKSIZE);
        chunk->end = (char*)chunk->mem + CHUNKSIZE;
        chunk->owner = &a.ref;

        Chunk* chunksHead = a.ref.chunks;
        chunk->prev = nullptr;
        chunk->next = chunksHead;

        if (chunksHead) chunksHead->prev = chunk;
        a.ref.chunks = chunk;

        Block* block = (Block*)chunk->mem;
        block->prev = block;
        block->next = block;

        block->handle = (uintptr_t)chunk | (BuddyAllocator::MAX_BINS - 1);

        a.ref.bins[BuddyAllocator::MAX_BINS - 1] = block;
    }

    // ------------------------------------------------------------------------
    BuddyAllocator::BuddyAllocator()
    {
        memset(this, 0x00, sizeof(*this));
        allocNewChunk(this);
    }

    // ------------------------------------------------------------------------
    BuddyAllocator::~BuddyAllocator()
    {
    }

    // ------------------------------------------------------------------------
    Bytes Block::freespace(Block* block, size_t size)
    {
        return Bytes{ (Byte*)block + HEADER_SIZE, (Byte*)block + size };
    }

    // ------------------------------------------------------------------------
    Block* Block::fromspace(Bytes bytes)
    {
        return (Block*)(bytes.begin - HEADER_SIZE);
    }

    // ------------------------------------------------------------------------
    void Block::setattr(size_t lvl, size_t bits)
    {
        handle &= ~0x1F;
        handle |= lvl | bits;
    }

    // ------------------------------------------------------------------------
    bool   Block::isfree() const { return (handle & USED_BIT) == 0; }
    Chunk* Block::owner()  const { return (Chunk*)(handle & ~0x1F); }
    size_t Block::level()  const { return size_t(handle & 0x0F); }
    
    // ------------------------------------------------------------------------
    inline static size_t getFreeLevel(BuddyAllocator const& a, size_t level)
    {
        while (level != BuddyAllocator::MAX_BINS) {
            if (a.bins[level]) break;
            level += 1;
        }
        return level;
    }

    // ------------------------------------------------------------------------
    inline static Block* getBuddyBlock(Chunk* chunk, Block* block, size_t size)
    {
        Byte* baseptr = (Byte*)chunk->mem;
        uintptr_t delta = (Byte*)block - baseptr;
        uintptr_t buddy = delta ^ size;

        return (Block*)(baseptr + buddy);
    }

    // ------------------------------------------------------------------------
    inline static void removeFreeBlock(Out<BuddyAllocator> a, Block* block, size_t level)
    {
        block->prev->next = block->next;
        block->next->prev = block->prev;

        if (block->prev != block->next) {
            a.ref.bins[level] = block->prev;
        }
        else {
            a.ref.bins[level] = nullptr;
        }
    }

    // ------------------------------------------------------------------------
    inline static void addFreeBlock(Out<BuddyAllocator> a, Block* block, size_t level)
    {
        Block* blockHead = a.ref.bins[level];
        if (blockHead) {
            block->prev = blockHead->prev;
            block->next = blockHead;

            blockHead->prev->next = block;
            blockHead->prev = block;
        }
        else {
            a.ref.bins[level] = block;
            block->prev = block;
            block->next = block;
        }
    }

    // ------------------------------------------------------------------------
    Bytes split(Out<BuddyAllocator> a, Block* block, size_t splitlevel, size_t level)
    {
        Chunk* chunk = (Chunk*)(block->handle & ~0x1F);
        size_t splitsize = getbuddysize(splitlevel);

        while (splitlevel != level) {
            splitlevel -= 1;
            splitsize >>= 1;

            Block* buddy = getBuddyBlock(chunk, block, splitsize);

            addFreeBlock(a, buddy, splitlevel);
            buddy->handle = block->handle;
            buddy->setattr(splitlevel, 0);
        }

        block->setattr(level, Block::USED_BIT);
        return Block::freespace(block, splitsize);
    }

    // ------------------------------------------------------------------------
    bool merge(Out<BuddyAllocator> a, Block* block, Block* buddy, size_t level)
    {
        size_t buddyInf = buddy->handle & 0x1F;
        if (buddyInf == level) {
            Block* merged = Math::min(buddy, block);
            removeFreeBlock(&a, buddy, level);
            merged->setattr(level + 1, 0);
            return true;
        }
        else {
            block->setattr(level, 0);
            return false;
        }
    }

    // ------------------------------------------------------------------------
    Bytes alloc(Out<BuddyAllocator> a, size_t level)
    {
        if (level >= BuddyAllocator::MAX_BINS)
            Tools::assert_fail(M_CL, "Unmanaged allocation not realized yet");

        size_t freeLevel = getFreeLevel(a.ref, level);
        if (freeLevel == BuddyAllocator::MAX_BINS) allocNewChunk(a);

        Block* block = a.ref.bins[freeLevel];
        M_ASSERT(block != nullptr);

        if (freeLevel == level) {
            removeFreeBlock(a, block, level);
            block->setattr(level, Block::USED_BIT);

            return Block::freespace(block, getbuddysize(level));
        }
        else {
            return split(a, block, freeLevel, level);
        }
    }

    // ------------------------------------------------------------------------
    void dealloc(Bytes bytes)
    {
        static const size_t MAX_SIZE = getbuddysize(15) - Block::HEADER_SIZE;
        if (size_t(bytes.end - bytes.begin) > MAX_SIZE)
            Tools::assert_fail(M_CL, "Unmanaged allocation not realized yet");

        Block* block = Block::fromspace(bytes);
        Chunk* chunk = block->owner();

        BuddyAllocator* a = chunk->owner;

        size_t level = block->level();
        size_t size = getbuddysize(level);
        while (level != BuddyAllocator::MAX_BINS - 1) {
            Block* buddy = getBuddyBlock(chunk, block, size);
            if (!merge(a, block, buddy, level)) break;

            block = Math::min(block, buddy);
            level += 1;
            size <<= 1;
        }

        // if (level == BuddyAllocator::MAX_BINS) freeChunk(block)

        addFreeBlock(a, block, level);
    }

} // namespace Memory