#include "memory/buddy_alloc2.h"
#include "core/data/bitset.h"
#include "core/math/basic.h"
#include "native/memory.h"

#include <memory.h>
#include <new>


namespace Memory {
    using RegionInfo = BuddyAlloc2::RegionInfo;
    using ChunkInfo = BuddyAlloc2::ChunkInfo;
    using Block = BuddyAlloc2::Block;

    static const size_t SREGION_SIZE = BuddyAlloc2::MIN_SIZE * (1 << 7);
    static const size_t LREGION_SIZE = BuddyAlloc2::MIN_SIZE * (1 << 15);
    static const size_t CHUNKSIZE = 2 * LREGION_SIZE;


    // ------------------------------------------------------------------------
    size_t getbuddy2level(size_t size)
    {
        static const size_t base = Math::log2(BuddyAlloc2::MIN_SIZE);
        size_t power = Math::log2(int(2 * size - 1));
        return power - base;
    }

    // ------------------------------------------------------------------------
    size_t getbuddy2size(size_t level)
    {
        static const size_t base = Math::log2(BuddyAlloc2::MIN_SIZE);
        return size_t(1) << (level + base);
    }

    // ------------------------------------------------------------------------
    RegionInfo* getsregion(Block* block)
    {
        uintptr_t ptr = (uintptr_t)block & ~(SREGION_SIZE - 1);
        return (RegionInfo*)ptr;
    }

    // ------------------------------------------------------------------------
    RegionInfo* getlregion(Block* block)
    {
        uintptr_t ptr = ((uintptr_t)block + (LREGION_SIZE - 1)) & ~(LREGION_SIZE - 1);
        return (RegionInfo*)ptr;
    }

    // ------------------------------------------------------------------------
    static void setusedattr(RegionInfo* region, Block* block, size_t level, bool used)
    {
        static const size_t base = Math::log2(BuddyAlloc2::MIN_SIZE);

        size_t delta = (Byte*)block - (Byte*)region;
        size_t index = delta >> (level + base);

        Data::setbittree(index, level, region->memmap, used);
    }

    // ------------------------------------------------------------------------
    inline static size_t getFreeLevel(BuddyAlloc2 const& a, size_t level, size_t maxLevel)
    {
        while (level != maxLevel) {
            if (a.bins[level]) return level;
            level += 1;
        }
        return BuddyAlloc2::MAX_BINS;
    }

    // ------------------------------------------------------------------------
    inline static void addFreeBlock(Out<BuddyAlloc2> a, Block* block, size_t level)
    {
        Block* blockHead = a.ref.bins[level];
        if (blockHead) {
            block->prev = blockHead->prev;
            block->next = blockHead;

            blockHead->prev->next = block;
            blockHead->prev = block;
        }
        else {
            a.ref.bins[level] = block;
            block->prev = block;
            block->next = block;
        }
    }

    // ------------------------------------------------------------------------
    inline static void removeFreeBlock(Out<BuddyAlloc2> a, Block* block, size_t level)
    {
        block->prev->next = block->next;
        block->next->prev = block->prev;

        if (block->prev != block->next) {
            a.ref.bins[level] = block->prev;
        }
        else {
            a.ref.bins[level] = nullptr;
        }
    }

    // ------------------------------------------------------------------------
    inline static Block* getBuddyBlock(Byte* region, Block* block, size_t size)
    {
        uintptr_t delta = (Byte*)block - region;
        uintptr_t buddy = delta ^ size;

        return (Block*)(region + buddy);
    }

    // ------------------------------------------------------------------------
    static Bytes split(Out<BuddyAlloc2> a, Byte* region, Block* block, size_t splitlevel, size_t level)
    {
        size_t splitsize = getbuddy2size(splitlevel);

        while (splitlevel != level) {
            splitlevel -= 1;
            splitsize >>= 1;

            Block* buddy = getBuddyBlock(region, block, splitsize);
            addFreeBlock(a, buddy, splitlevel);
        }

        setusedattr((RegionInfo*)region, block, level, true);
        return Data::toBytes(block, splitsize);
    }

    // ------------------------------------------------------------------------
    inline static void insertSRegions(Out<BuddyAlloc2> a, BuddyAlloc2* owner, Byte* area, Byte* end)
    {
        while (area != end) {
            new(area) RegionInfo(owner);
            split(a, area, (Block*)area, 7, 0);

            area += SREGION_SIZE;
        }
    }

    // ------------------------------------------------------------------------
    inline static bool insertLRegion(Out<BuddyAlloc2> a, BuddyAlloc2* owner, Byte* area, Byte* sregions2)
    {
        Block* block = (Block*)area;
        Block* head = a.ref.bins[15];
        if (head == nullptr) {
            a.ref.bins[15] = block;
            block->prev = block;
            block->next = block;
        }
        else if (head->next == head) {
            block->prev = head;
            block->next = head;
            head->prev = block;
            head->next = block;
        }
        else {
            return false;
        }
        
        Block* meta = (Block*)(sregions2 + BuddyAlloc2::MIN_SIZE);
        setusedattr((RegionInfo*)sregions2, meta, 0, true);
        removeFreeBlock(&a, meta, 0);
        new(meta) RegionInfo(owner);
        return true;
    }

    // ------------------------------------------------------------------------
    static void allocNewChunk(Out<BuddyAlloc2> a, size_t ownerOffset)
    {
        Byte* sregions1 = (Byte*)Native::mcommit(nullptr, CHUNKSIZE);
        Byte* lregion = (Byte*)getlregion((Block*)sregions1);
        Byte* sregions2 = lregion + LREGION_SIZE;

        BuddyAlloc2* owner = (BuddyAlloc2*)(sregions1 + ownerOffset);
        owner = ownerOffset ? owner : &a.ref;

        insertSRegions(a, owner, sregions1, lregion);
        insertSRegions(a, owner, sregions2, sregions1 + CHUNKSIZE);
        if (!insertLRegion(a, owner, lregion, sregions2)) {
            insertSRegions(a, owner, lregion, sregions2);
        }

        ChunkInfo* chunk = (ChunkInfo*)sregions1;
        chunk->next = a.ref.chunks;
        a.ref.chunks = chunk;
    }

    // ------------------------------------------------------------------------
    BuddyAlloc2::RegionInfo::RegionInfo(BuddyAlloc2* a)
    {
        memset(this, 0x00, sizeof(*this));
        this->owner = a;
    }

    // ------------------------------------------------------------------------
    BuddyAlloc2::~BuddyAlloc2()
    {

    }

    // ------------------------------------------------------------------------
    void* BuddyAlloc2::operator new(size_t size)
    {
        static const size_t MEMLVL = getbuddy2level(sizeof(BuddyAlloc2));
        static const size_t MEMOFF = getbuddy2size(MEMLVL);

        BuddyAlloc2 a;
        memset(&a, 0x00, sizeof(BuddyAlloc2));
        allocNewChunk(&a, MEMOFF);

        Block* block = a.bins[MEMLVL];
        RegionInfo* region = getsregion(block);

        removeFreeBlock(&a, block, MEMLVL);
        setusedattr(region, block, MEMLVL, true);

        memcpy(block, &a, sizeof(BuddyAlloc2));
        memset(&a, 0x00, sizeof(BuddyAlloc2));
        return block;
    }

    // ------------------------------------------------------------------------
    Bytes alloc(Out<BuddyAlloc2> a, size_t level)
    {
        if (level >= BuddyAlloc2::MAX_BINS)
            Tools::assert_fail(M_CL, "Unmanaged allocation not realized yet");

        const bool isSmallAlloc = level < 7;
        size_t freeLevel = getFreeLevel(a.ref, level, isSmallAlloc ? 7 : 16);
        if (freeLevel == BuddyAlloc2::MAX_BINS) {
            freeLevel = isSmallAlloc ? level : 15;
            allocNewChunk(a, 0);
        }

        Block* block = a.ref.bins[freeLevel];
        RegionInfo* region = isSmallAlloc ? getsregion(block) : getlregion(block);
        M_ASSERT(block != nullptr);

        if (freeLevel == level) {
            removeFreeBlock(a, block, level);
            setusedattr(region, block, level, true);
            return Data::toBytes(block, getbuddy2size(level));
        }
        else {
            return split(&a, (Byte*)region, block, freeLevel, level);
        }

        return Data::noBytes;
    }

    // ------------------------------------------------------------------------
    void dealloc2(Bytes bytes)
    {
        size_t level = getbuddy2level(bytes.end - bytes.begin);
        if (level > 15)
            Tools::assert_fail(M_CL, "Unmanaged allocation not realized yet");

        Block* block = (Block*)bytes.begin;
        RegionInfo* region = level < 8 ? getsregion(block) : getlregion(block);

        /*BuddyAlloc2* a = region->owner;
        size_t size = getbuddy2size(level);
        while (level != BuddyAlloc2::MAX_BINS - 1) {
            Block* buddy = getBuddyBlock((Byte*)region, block, size);
            removeFreeBlock(a, buddy, level);

            block = Math::min(block, buddy);
            level += 1;
            size <<= 1;
        }

        // if (level == BuddyAllocator::MAX_BINS) freeChunk(block)

        addFreeBlock(a, block, level);*/
    }

} // namespace Memory