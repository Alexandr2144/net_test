#include "memory/region.h"

#include "core/tools/assert.h"
#include "memory/global_heap.h"
#include <memory.h>


namespace Memory {
   // -------------------------------------------------------------------------
   Region::Region()
      : m_bytes(Memory::buddy_alloc(0, 0))
      , m_last(0)
   {
   }

   // -------------------------------------------------------------------------
   Region::~Region()
   {
      Memory::buddy_dealloc(m_bytes);
   }

   // -------------------------------------------------------------------------
   size_t Region::last() const
   {
      return m_last;
   }

   // -------------------------------------------------------------------------
   Bytes Region::reserve(size_t offset)
   {
      Byte* reserved = m_bytes.begin + m_last;
      size_t size = Data::count(m_bytes);

      if (offset > size) {
         m_bytes = Memory::buddy_realloc(m_bytes, offset);
      }
      M_ASSERT(offset <= Data::count(m_bytes));
      return Bytes{ reserved, m_bytes.begin + offset };
   }

   // -------------------------------------------------------------------------
   Bytes Region::read(size_t offset) const
   {
      Byte* begin = this->m_bytes.begin + offset;
      Byte* end = this->m_bytes.begin + this->m_last;
      return Bytes{ begin, end };
   }

} // namespace Memory