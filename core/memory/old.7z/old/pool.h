#pragma once
#ifndef MEMORY_POOL_H
#define MEMORY_POOL_H

#include <stddef.h>

#include "core/data/bytes.h"


namespace Memory {
	using Data::Bytes;
	using Data::Byte;

	class Pool {
      struct Chunk {
         Chunk* next;
         size_t used;
      };
		struct Block {
         Block* next;
		};

   public:
      Pool(size_t msize);
		~Pool();

      Bytes alloc();
      void dealloc(Byte* mem);
      void reset(size_t msize);

   private:
      size_t m_msize;
	};

	

} // namespace Memory


#endif // MEMORY_POOL_H